/**
 * Created by harshmehta6711 on 17-11-2016.
 */
//code for sign in , sign up(register)

var bcrypt = require('bcryptjs');






exports.register=function (req,res) {
//logic for encryption and registration in DB


};