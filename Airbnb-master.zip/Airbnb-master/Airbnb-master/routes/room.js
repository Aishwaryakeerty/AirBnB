/**
 * Created by harshmehta6711 on 22-11-2016.
 */

var mysql=require('../AirbnbBackend/services/mysql');
var mq_client = require('../rpc/client');
var moment=require('moment');

exports.getDetails=function (req,res)
{
    var msg_payload={
        place: req.param('place'),
        start: req.param('start'),
        end: req.param('end'),
        guests: req.param('guests'),
        queue:"login"
    };
    console.log("IN NODE : "+msg_payload);
    mq_client.make_request('login_queue',msg_payload, function(err,results){

        console.log(results);
        if(err){
            throw err;
        }
        else
        {
            if(results.statusCode === 200){
                console.log("valid Login");
               // console.log("MONGO LENGTH IN NODE: "+roommongo.length);
                res.send({"statusCode":200,"roomsql":results.roomsql,"roommongo":results.roommongo});
            }
            else {

                console.log("Invalid Login");
                res.send({"login":"Fail"});
            }
        }
    });

};

exports.getRoomDetails=function (req,res)
{
    var msg_payload={
        proname: req.param('data'),
        queue:"room_details"
    }

    mq_client.make_request('login_queue',msg_payload, function(err,results){

        console.log(results);
        if(err){
            throw err;
        }
        else
        {
            if(results.statusCode === 200){
                console.log("valid Login");
                //req.session.fname=results.fname;
                res.send({"room":results.room, "statusCode":200, "image":results.image});
                console.log("success");
            }
            else {

                console.log("Invalid Login");
                res.send({"login":"Fail"});
            }
        }
    });

};

exports.checkout=function (req,res)
{

    var sdate=req.param('sdate');
    var edate=req.param('edate');
    var a = moment(sdate,'M/D/YYYY');
    var b = moment(edate,'M/D/YYYY');
    var diffDays = b.diff(a, 'days');
    var msg_payload={
        proid: req.param('proid')

    }

};