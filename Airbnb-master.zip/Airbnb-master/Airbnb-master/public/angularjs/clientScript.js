/**
 * Created by harshmehta6711 on 17-11-2016.
 */

var clientModule=angular.module("clientModule",['ui.router','ngAutocomplete']).run(function ($rootScope) {
    $rootScope.authenticated = false;
    $rootScope.current_user = '';

    // $rootScope.signout = function(){
    //     $http.get('auth/signout');
    //     $rootScope.authenticated = false;
    //     $rootScope.current_user = '';
    // };

});

clientModule.config(function ($stateProvider,$urlRouterProvider,$locationProvider) {
    console.log("inside angular");
   // $locationProvider.html5Mode(true);

    $stateProvider
        .state('home',{
            url:'/',
            //templateUrl:"../templates/index.html"
            views:{
                'index': {
                    templateUrl: '../templates/indexpartial.html'

                },
                'header':{
                    templateUrl:'../templates/NavigationBar.html'
                }

            }




        })
        .state('room_listing',{
            url:'/room_listing/:place/:start/:end/:guests',
            //templateUrl:"../templates/index.html"
            views:{
                'index': {
                    templateUrl: '../templates/product_listing.html'

                },
                'header':{
                    templateUrl:'../templates/NavigationBar.html'
                }

            }
            }
        )
        .state('room_details',{
                url:'/room_details/:id/:startdate/:enddate/:guests',
                //templateUrl:"../templates/index.html"
                views:{
                    'index': {
                        templateUrl: '../templates/RoomDetails.html'

                    },
                    'header':{
                        templateUrl:'../templates/NavigationBar.html'
                    }

                }
            }
        );;
   $urlRouterProvider.otherwise('/');

});



clientModule.controller('ctrlNavigation',function ($scope,$http,$rootScope,$state) {
    console.log("inside controller");
    $scope.register=function () {
        console.log($scope.user.lname);
        $http({
            method : 'POST',
            url : '/register',
            data : $scope.user
        }).success(function(data) {
            //checking the response data for statusCode
            if (data.statusCode == 401) {
                $rootScope.authenticated = true;
               // $scope.validlogin = true;
            }
            else
            {
                $scope.validlogin = false;
                $scope.invalid_login = true;
            }
            //Making a get call to the '/redirectToHomepage' API
            //window.location.assign("/homepage");
        }).error(function(error) {
            $scope.validlogin = true;
            $scope.invalid_login = true;
        });
    }
    
});

clientModule.controller('TestCtrl',function ($scope,$http,$state,$stateParams) {

    $scope.result1 = '';
    $scope.options1 = null;
    $scope.details1 = '';


    $scope.searchOptions=function () {

        console.log($scope.journey.place+"....."+$scope.journey.sdate+"..."+$scope.journey.edate+"......."+$scope.journey.guest.selectedIndex);
        $state.go('room_listing',{
            //results:data.results.room
            place:$scope.journey.place,
            start:$scope.journey.sdate,
            end:$scope.journey.edate,
            guests:$scope.journey.guest
        });

/*        $http({
            method : 'POST',
            url : '/getRoom',
            data : {"journey":$scope.journey }
        }).success(function(data) {
            //checking the response data for statusCode
            console.log("DATA IN ANGULAR : "+data );
            if (data.statusCode == 200) {
             console.log("Successfully back to angular");
                console.log($scope.journey.place+"....."+$scope.journey.sdate+"..."+$scope.journey.edate+"......."+$scope.journey.guest);
                console.log(data.results.room);
                 $state.go('room_listing',{
                    //results:data.results.room
                     place:$scope.journey.place,
                     start:$scope.journey.sdate,
                     end:$scope.journey.edate,
                     guests:$scope.journey.guest
                 });

            }
            else
            {
              //  $rootScope.authenticated = true;

            }
            //Making a get call to the '/redirectToHomepage' API
            //window.location.assign("/homepage");
        }).error(function(error) {
            $scope.validlogin = true;
            $scope.invalid_login = true;
        });*/
    }


});

clientModule.controller('ProdCtrl',function ($scope,$http,$state,$stateParams) {

$scope.params=$stateParams;

console.log("PRODUCT DETAILS : "+$stateParams.place+"  START: "+$stateParams.start+"   END: "+$stateParams.end+"  GUESTS: "+$stateParams.guests);
    var start=new Date($stateParams.start);
    var end=new Date($stateParams.end);
    $scope.start=start;
    $scope.end=end;
    $scope.guest=$stateParams.guests;
    $http({
        method : 'POST',
        url : '/getRoom',
        data : {"place":$stateParams.place,"start":$stateParams.start,"end":$stateParams.end,"guests":$stateParams.guests }
    }).success(function(data) {
        //checking the response data for statusCode

        if (data.statusCode == 200) {
            console.log("Successfully back to angular");
            $scope.roomdetails=[];

            for (i=0;i<data.roomsql.length;i++){

                $scope.roomdetails.push({'price':data.roomsql[i].price,'path':data.roommongo[i].images[0].img1,'id':data.roomsql[i].id})
            }

        }
        else
        {
            //  $rootScope.authenticated = true;
            console.log("401");
        }

    }).error(function(error) {
        console.log("ERROR");
    });

});

clientModule.controller('ctrlRoomDetails',function ($scope,$http,$rootScope,$stateParams) {
    console.log("inside controller");
    // $scope.register=function () {
    // console.log($scope.user.lname);
    $http({
        method : 'POST',
        url : '/getRoomd',
        data : {
            "data": $stateParams.id
        }
    }).success(function(data) {
        //checking the response data for statusCode
        if (data.statusCode == 401) {
            $rootScope.authenticated = true;
            // $scope.validlogin = true;
        }
        else
        {
            var start=new Date($stateParams.startdate);
            var end=new Date($stateParams.enddate);
            $scope.startdate=start;
            $scope.enddate=end;
            $scope.guests=$stateParams.guests;
            $scope.validlogin = false;
            $scope.invalid_login = true;
            $scope.proname=data.room[0].ptitle;
            $scope.description=data.room[0].description;
            $scope.costpn=data.room[0].price;
            $scope.loc=data.room[0].city;
            $scope.locstate=data.room[0].state;
            $scope.mainImg=data.image[0].img1;
            console.log(data.room[0].ptitle);
            console.log(data.room[0].address);
        }
        //Making a get call to the '/redirectToHomepage' API
        //window.location.assign("/homepage");
    }).error(function(error) {
        $scope.validlogin = true;
        $scope.invalid_login = true;
    });


});