/**
 * Created by DELL on 11/26/2016.
 */
var mongo = require("./mongo");
var mongoURL = "mongodb://localhost:27017/airbnb";
var mysql=require('./mysql');

function handle_request(msg, callback){
    if(msg.queue==="login")
    {

        var res = {};

        var json_responses;


        var places=msg.place.split(", ");
        var g=msg.guests.substring(0,1,msg.guests);
        console.log("GUESTS :"+g);
        console.log(places[0]+"--"+places[1]+"---"+places[2]);
        var city="%"+places[0]+"%";
        var state="%"+places[1]+"%";
        var country="%"+places[2]+"%";
        var query = "select * from property where (city like '"+city+"' or state like '"+state+"' or address like '"+city+"' or address like '"+state+"' or address like '"+country+"') and guests>="+g+"";
        console.log(query);
        mysql.fetchData(function(err,results){
            if(err){
                console.log("Invalid Login");
                throw err;

            }
            else
            {
                if(results.length > 0){

                    var results1=[];
                    for(var i=0;i<results.length;i++) {
                        console.log(results[i].address+"====="+results[i].id);
                        results1[i]=results[i].id;
                    }

                    mongo.connect(mongoURL, function() {
                        console.log('Connected to mongo at: ' + mongoURL);
                        var mongorows=[];
                        for(i=0;i<results1.length;i++) {
                            mongo.collection('property').find({"id":results1[i]}).toArray(function (err, rows) {
                                if (rows) {
                                    for (var i in rows) {
                                        mongorows.push(rows[i]);
                                        console.log("HERE  " + rows[i].id+"    "+mongorows.length);

                                    }
                                }
                                else {
                                    console.log("MONGO SEARCH IN ERROR    " + err);
                                }
                                json_responses = {"statusCode": 200, "roomsql": results, "roommongo": mongorows};
                                console.log("before redirect");
                                callback(null, json_responses);
                            });
                        }
                    });
                   /* json_responses = {"statusCode" : 200,"roomsql":results,"roommongo":results1};
                    console.log("before redirect");
                    callback(null, json_responses);*/
                    // res.send(json_responses);
                    //}
                }
                else {
                    console.log("Invalid Login");
                    json_responses = {"statusCode" : 401};
                    //res.send(json_responses);
                    callback(null, json_responses);
                }
            }
        },query);
    }

   if(msg.queue=="room_details")
   {
       var json_responses;

       var pid=msg.proname;

       var query = "select * from property where id='"+pid+"'";
       console.log(query);
       mysql.fetchData(function(err,results){
           if(err){
               console.log("Invalid Login");
               throw err;

           }
           else
           {
               if(results.length > 0){
                   var proid=results[0].id;
                   var image;
                   console.log("This is the proid for selected pro"+ proid);

                   //mongo begins

                   mongo.connect(mongoURL, function() {
                       console.log("inside connect");
                       console.log('Connected to mongo at: ' + mongoURL);
                       var coll = mongo.collection('property');



                       coll.findOne({"id": results[0].id}, function (err, user) {
                           console.log('inside find');
                           if (user) {


                               console.log("the path is" + user.images[0].img1);
                               image=user.images;
                               //res.send(json_responses);

                               for(var i=0;i<results.length;i++) {
                                   console.log(results[i].address);
                                   console.log(results[i].ptitle);
                               }
                               console.log(image);
                               json_responses = {"statusCode" : 200,"room":results,"image":image};
                               console.log("before redirect");
                               callback(null, json_responses);



                           } else {
                               console.log("returned false"+err);


                           }


                       });
                   });


                   //mongo ends

                   //var dbpass=results[0].password;
                   //if(bcrypt.compareSync(password, dbpass))
                   //{
                   /* for(var i=0;i<results.length;i++) {
                    console.log(results[i].address);
                    console.log(results[i].ptitle);
                    }
                    console.log(image);
                    json_responses = {"statusCode" : 200,"room":results,"image":image};
                    console.log("before redirect");
                    callback(null, json_responses);*/
                   // res.send(json_responses);
                   //}
               }
               else {
                   console.log("Invalid Login");
                   json_responses = {"statusCode" : 401};
                   //res.send(json_responses);
                   callback(null, json_responses);
               }
           }
       },query);

   }


    else {
       console("Failure: "+msg.queue);
        var json_responses = {
            "statusCode" : 401
        };
        callback(null,json_responses);


    }
}





exports.handle_request = handle_request;
