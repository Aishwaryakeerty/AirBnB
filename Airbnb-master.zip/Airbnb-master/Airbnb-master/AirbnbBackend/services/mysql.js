var mysql=require('mysql');

function getConnection(){
    var connection = mysql.createConnection({
        host : 'localhost', //host where mysql server is running
        user : 'root', //user for the mysql application
        password : 'system', //password for the mysql application
        database : 'airbnb11', //database name
        port : 3306 //port, it is 3306 by default for mysql
    });
    return connection;
}
function fetchData(callback,sqlQuery){
    console.log("\nSQL Query::"+sqlQuery);
    var connection=getConnection();
    connection.query(sqlQuery, function(err, rows, fields) {
        if(err){
            console.log("ERROR: " + err.message);
        }
        else
        { // return err or result
            console.log("DB Results:"+rows);
            callback(err, rows);
        }
    });
    console.log("\nConnection closed..");
    connection.end();
}
exports.fetchData=fetchData;